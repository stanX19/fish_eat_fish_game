package com.deepseadevs.fisheatfish.game;

public class Settings {
    public static boolean showHitBox;
}
