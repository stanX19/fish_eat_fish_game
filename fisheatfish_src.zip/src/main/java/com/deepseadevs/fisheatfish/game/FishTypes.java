package com.deepseadevs.fisheatfish.game;

public enum FishTypes {
    SMALL,
    MEDIUM,
    LARGE,
    GIANT,
    PLAYER_SMALL,
    PLAYER_MEDIUM,
    PLAYER_LARGE,
    PLAYER_GIANT
}
