package com.deepseadevs.fisheatfish.widgets.labels;

import com.deepseadevs.fisheatfish.widgets.GameStyles;

public class BoldLabel extends GeneralLabel {
    public BoldLabel(String text) {
        super(text, GameStyles.BOLD_LABEL_FONT, GameStyles.TEXT_COLOR);
    }
}
