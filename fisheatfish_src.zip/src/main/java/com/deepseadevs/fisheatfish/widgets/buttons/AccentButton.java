package com.deepseadevs.fisheatfish.widgets.buttons;

import com.deepseadevs.fisheatfish.widgets.GameStyles;

public class AccentButton extends ColoredButton {
    public AccentButton(String text) {
        super(text, GameStyles.ACCENT_COLOR);
    }
}
