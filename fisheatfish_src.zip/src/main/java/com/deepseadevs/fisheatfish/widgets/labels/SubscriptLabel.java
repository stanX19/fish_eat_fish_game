package com.deepseadevs.fisheatfish.widgets.labels;

import javafx.scene.text.Font;

public class SubscriptLabel extends GeneralLabel {
    public SubscriptLabel(String text) {
        super(text, Font.font("Arial", 12), "#aaaaaa");
    }
}
