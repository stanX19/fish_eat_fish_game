package com.deepseadevs.fisheatfish.widgets.buttons;

import com.deepseadevs.fisheatfish.widgets.GameStyles;

public class MenuAccentButton extends MenuColoredButton {
    public MenuAccentButton(String text) {
        super(text, GameStyles.ACCENT_COLOR);
    }
}
